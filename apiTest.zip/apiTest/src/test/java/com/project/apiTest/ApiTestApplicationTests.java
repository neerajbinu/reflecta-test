package com.project.apiTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
